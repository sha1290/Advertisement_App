import 'package:firebase_core/firebase_core.dart';

FirebaseOptions firebaseOptions = const FirebaseOptions(
    apiKey: 'AIzaSyAnkrFbuqzLOUwWpnJ79BpSJe52YazxVSw',
    appId: '1:825601011628:android:ab6f9eb840a86a723c1409',
    messagingSenderId: '825601011628',
    projectId: 'rapid-project-fcfc3');