import 'package:flutter/material.dart';
import 'package:footware_client/pages/login_page.dart';
import 'package:footware_client/pages/product_description_page.dart';
import 'package:footware_client/widgets/multi_select_drop_down.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../widgets/drop_down_btn.dart';
import '../widgets/product_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Add2bold',
            style: TextStyle(fontWeight:FontWeight.bold),
          ),
        ),
        actions:[
          IconButton(onPressed: (){
            GetStorage box = GetStorage();
            box.erase();
            Get.offAll(LoginPage());
          }, icon: Icon(Icons.logout))
        ]
      ),
      body: Column(
        children: [
          SizedBox(
            height: 50,
            child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: 7,
                itemBuilder: (context,index){
                return Padding(
                  padding: const EdgeInsets.all(6),
                  child: Chip(label: Text('Category')),
                );
            }),
          ),
          Row(
            children: [
              Flexible(
                child: DropDownBtn(
                  items: ['Trending','New Item', 'High to low', 'Low to high'],
                  selectedItemText: 'Sort',
                  onSelected: (selected) {},
                ),
              ),
              Flexible(child: MultiSelectDropDown(
                items: ['item1', 'item2','item3','item4'],
                onSelectionChanged: (selectedItems ) {},
              ))
            ],
          ),
          Expanded(
            child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,
                  childAspectRatio: 0.8,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8
                ),
                itemCount: 16,
                itemBuilder: (context, index){
                  return ProductCard(
                    name: 'Heart of Stone',
                    imageUrl: 'https://filmfare.wwmindia.com/content/2023/aug/upcominghollywoodmovies21690962006.jpg',
                    price: 350,
                    offerTag: '33 % off',
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ProductDescriptionPage()),
                      );
                    },
                  );
                }),
          )

        ],
      )
    );
  }
}
