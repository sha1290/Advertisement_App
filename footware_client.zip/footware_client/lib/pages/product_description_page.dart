import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';



class ProductDescriptionPage extends StatelessWidget{
  const ProductDescriptionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Details', style: TextStyle(fontWeight: FontWeight.bold )),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(
                'https://filmfare.wwmindia.com/content/2023/aug/upcominghollywoodmovies21690962006.jpg',
                fit: BoxFit.contain,
                width: double.infinity,
                height: 200,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Heart of Stone',
              style: const TextStyle(
                   fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
            ),
            const SizedBox(height: 20),
            Text(
              'Movie Description',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),
            Text(
              'The past month was a big one for movies with Greta Gerwig’s Barbie and Christopher Nolan’s Oppenheimer clashing at box offices worldwide. As the dust settles, August has rolled in with some heavily anticipated movies. Among the top releases of the month is Heart of Stone. The spy thriller film starring Gal Gadot and Jamie Dornan marks Alia Bhatt’s Hollywood debut. Another major release involves a new DC superhero arriving on the big screen. The live-action Blue Beetle will see the comic book character come to life. Meanwhile, a new animated Teenage Mutant Ninja Turtles movie is coming soon.',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),
            Text(
              'RS: 300 Only',
              style: TextStyle(
                fontSize: 20,
                color: Colors.green,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 15), backgroundColor: Colors.indigo),
                  child:  const Text(
                    'Buy Now',
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                onPressed: () {

              },
            ),
              ),
          ],

        ),
      ),
    );
  }
}
