import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:footware_client/pages/home_page.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../model/user.dart';

class LoginController extends GetxController{

  GetStorage box = GetStorage();
  FirebaseFirestore firestore = FirebaseFirestore.instance;
  late CollectionReference userCollection;

  TextEditingController registerNameCtrl = TextEditingController();
  TextEditingController registerNumberCtrl = TextEditingController();
  TextEditingController registerEmailCtrl = TextEditingController();
  TextEditingController registerPasswordCtrl = TextEditingController();
  TextEditingController registerConfirmPasswordCtrl = TextEditingController();

  TextEditingController loginEmailCtrl = TextEditingController();
  TextEditingController loginPasswordCtrl = TextEditingController();

  User? loginUser;

  @override
  void onReady() {
    Map<String,dynamic>? user = box.read('loginUser');
    if(user != null){
      loginUser = User.fromJson(user);
      Get.to(const HomePage());
    }
    super.onReady();
  }

  @override
  void onInit(){
    userCollection = firestore.collection('users');
    super.onInit();
  }

  addUser(){
    try {
      if(registerNameCtrl.text.isEmpty || registerNumberCtrl.text.isEmpty ||registerEmailCtrl.text.isEmpty ||registerPasswordCtrl.text.isEmpty ||registerConfirmPasswordCtrl.text.isEmpty ){
        Get.snackbar('Error','Please fill the field',colorText: Colors.red);
        return;
      }
      DocumentReference doc = userCollection.doc();
      User user = User(
        id: doc.id,
        name: registerNameCtrl.text,
        number: int.parse(registerNumberCtrl.text),
        email: registerEmailCtrl.text,
        password: registerPasswordCtrl.text,
        confirm: registerConfirmPasswordCtrl.text,
      );
      final userJson = user.toJson();
      doc.set(userJson);
      registerNameCtrl.clear();
      registerNumberCtrl.clear();
      registerEmailCtrl.clear();
      registerPasswordCtrl.clear();
      registerConfirmPasswordCtrl.clear();
      Get.snackbar('Success', 'User added successfully',colorText: Colors.green);

    } catch (e) {
      Get.snackbar('Error', e.toString(),colorText: Colors.green);
      print(e);

    }

  }

  Future<void> loginWithPhone() async {
    try {
      String email = loginEmailCtrl.text;
      String password = loginPasswordCtrl.text;
      if (email.isNotEmpty && password.isNotEmpty) {
        var querySnapshot = await userCollection
            .where('email', isEqualTo: email)
            .where('password', isEqualTo: password)
            .limit(1)
            .get();

        if (querySnapshot.docs.isNotEmpty) {
          // User found, perform successful login
          var userDoc = querySnapshot.docs.first;
          var userData = userDoc.data() as Map<String, dynamic>;
          box.write('loginUser',userData);
          loginEmailCtrl.clear();
          loginPasswordCtrl.clear();
          Get.to(const HomePage());
          Get.snackbar('Success', 'Login Successful', colorText: Colors.green);
        } else {
          // No user found with provided credentials
          Get.snackbar('Error', 'Invalid email or password',
              colorText: Colors.red);
        }
      } else {
        // Fields are empty
        Get.snackbar('Error', 'Please enter email and password',
            colorText: Colors.red);
      }
    }catch (error) {
      print("Failed to login: $error");
      Get.snackbar('Error', 'Failed to lo gin', colorText: Colors.red);
    }
  }
}